<?php

require('inc/nav.php');

//RUN CODE IF HIT SUBMIT
if(isset($_POST['submit']))
{
    
// Getting VALUES FROm FORM

    $task_name = $_POST['task_name'];
    $date = $_POST['date'];
    $description_task = $_POST['description'];

    // SQL Query

    $SQL_insert = "INSERT INTO `todo` (`name`, `description`, `date`, `done`) VALUES ('$task_name','$description_task','$date',0)";

    // Running Query


    if($conn->query($SQL_insert))
    {
       $msg="suc"; 
    }





}



?>



<br>
<form class="form container box-shadow_form card p-4 table-bordered" action="#" method="POST">
    <h1> <b>&#43; </b>Add New Task</h1> 

    <?php

    if(isset($_POST['submit']))
    {
        if($msg=='suc')
        {
            $last_id = $conn->insert_id;


            //SENDING SMS


            // Account details
                
                    
       
        ?>
              <div class="ml-auto"> <div class=" btn-success col-md btn-lg col-md-12"> <b> <a style="color:white;" href="view.php">LAST TASK ID <?php echo $last_id; ?> View </a>

            
            
       </div></b> </div>            

        <?php
        }

        if($msg=='err_ins')
        {
            echo '    <div class="ml-auto"> <div class=" btn-danger col-md btn-lg col-md-12"> <b> Something went Wrong.! </b> </div> </div>
            ';

        }
    }

    ?>

    <br>

    <div class="row">

        <div class="col-md col-md-7">
            <label class="label form" for="task_name"><b>Task Name : </b></label> <br>
            <input class="form-control " type="text" name="task_name" placeholder="Name of Task" required>
        </div>
        <br>
        <div class="col-md-5 col-sm-12">
            


        <label class="label form" for="Date"><b>Date : </b></label> <br>
            <input class="form-control " type="date" name="date"  required>



        </div>
    </div>

    <div class="row">

        <div class="col-md col-md-7">
            <label for="description"><b>Description: </b></label> <br>
            <textarea class="form-control " type="text" name="description" placeholder="Description" > </textarea>
        </div>

        
    </div>
    <br>
    <br> <input class="btn btn-primary" type="submit" value="Add" name="submit">

</form>
