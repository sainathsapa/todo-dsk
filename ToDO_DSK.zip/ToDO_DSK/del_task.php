<?php

require('inc/nav.php');
$id=$_GET['id'];
$qry = "SELECT * FROM todo WHERE id='$id'";
$qry_exe = $conn->query($qry);
$row=$qry_exe->fetch_assoc();



if(isset($_POST['submit']))
{

    $qry_del="DELETE FROM todo WHERE id=$id";
    if($conn->query($qry_del)==true)
    {

        header("Location: view.php?suc=$id");

    }

   





}
?>

<br>
<div class="container card">
<h1 class=""> Delete TASK </h1>
<hr>

<form action="#" method="POST">
<h2 class="heading text-center bg-danger text-white"> Are You Sure to Delete </h2>
<br>
<div class='text'> <b> TASK ID : </b> <?php echo $row['id']; ?></div>
<div class='text'> <b> TASK NAME : </b> <?php echo $row['name']; ?></div>
<div class='text'> <b> TASK Description : </b> <?php echo $row['description']; ?></div>
<div class='text'> <b> TASK Date : </b> <?php echo $row['date']; ?></div>
<div class='text'> <b> Completed : </b> 

<?php 


if($row['done']==1)
{
    echo "Yes";

}
else
{
    echo "No";
}



?>


</div>

<center>
<button class="btn btn-lg btn-success col-md-1 p-0 py-0 px-0" type="submit" name="submit" value="Delete"> Yes </button>
<a class="btn btn-lg btn-danger col-md-1 p-0 py-0 px-0" href="view.php"> Back </a>

</center>
</form>
<br>

</div>


