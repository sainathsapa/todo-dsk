<script src="assets/js/jquery-3.5.1.min.js"></script>

<script src="assets/js/bootstrap.js"></script>

<script src="assets/table/datatables.js"></script>
