<link rel="stylesheet" href="assets/style/bootstrap.css">
<link rel="stylesheet" href="assets/style/custom.css">
<link rel="stylesheet" href="assets/table/datatables.css">
