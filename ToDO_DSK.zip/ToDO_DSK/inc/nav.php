<?php

session_start();
require('db.php');
require('style.php');
require('js.php');


?>
<a class="copy" href="http://dsksolutions.unaux.com"><img src="assets/images/logo.png" height="70px"/></a>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
<!-- Bootstrap CSS -->
<!-- Meta TAGS -->
<meta name="description" content="To Do List, DSK Solutions Kubeer Pvt. Ltd. Ask Here For Tech And Music Solutions. Home Page | Dj Sai Kubeer Softwares And Worlds Pvt. Ltd., Any Technical And Music Issue Solutions"/>
<meta name="author" content="Sainath Sapa"/>
<meta name="copyright" content="Dj Sai Kubeer Softwares And Worlds Pvt. Ltd. All Rights Reserved."/>
<meta name="robots" content="index,follow"/>
<meta name="googlebot" content="index,follow"/>
<link rel="shortcut icon" href="assets/images/logo.png" type="image/png"/>
<title> DSK Solutions Pvt. Ltd. 2020 | Management Software </title>

</head>
<br>
                                            
 <h1 class="text-center head_line "> Todo List  </h1>
 <strong class="ml-5 pl-5"> By Sainath Sapa -Assigned TASK </strong>

<br>
<nav class=" navbar navbar-expand-md navbar-dark bg-primary">
  <a class="navbar-brand" href="#">Welcome To DO </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#Nav_bar" aria-controls="Nav_bar" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="Nav_bar">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php"><img class="img px-1"src="assets/images/home.svg" height="20px" />Home <span class="sr-only">(current)</span></a>
      </li>
   
      <li class="nav-item dropdown text-white bg-primary">
        <a class="nav-link dropdown-toggle text-white " href="#" id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img class="img px-1"src="assets/images/search.png" height="20px" />ToDo</a>
        <div class="dropdown-menu bg-primary " aria-labelledby="dropdown04">

          <a class=" p-1 px-2 text-left text-white" href="add_new.php"><img class="img px-1"src="assets/images/add.png" height="20px" /> Add New </a> 
          <hr color="white">
          <a class=" p-1 px-2 text-left text-white" href="view.php"><img class="img px-1"src="assets/images/view.png" height="20px" /> View List </a>

        </div>
      </li>


    </ul>
    <div class="nav-item text-white log_out mr-auto">
        <a class="nav-link text-white ml-auto" href="exit.php"><img class="img px-1"src="assets/images/log_out.png" height="20px" />Exit
       </a>
      </div>
  </div>
</nav>
<body background="assets/images/bg.jpeg">
