<?php

require('inc/nav.php');

header("Location:../")

?>