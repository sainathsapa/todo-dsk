<?php


require('inc/nav.php');

$qry = "SELECT * FROM todo ";

$qry_exe = $conn->query($qry);

?>
<script>
    
function changeValue(str) {



var xmlhttp = new XMLHttpRequest();
xmlhttp.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
  }
};
xmlhttp.open("GET","change.php?id="+str,true);
xmlhttp.send();
location.reload();

return;
} 



    </script>
<div class="conainer bg-white pl-3 pr-5  ml-5 mr-5">

<table class="table table-striped table-primary p-1 m-1 table-bordered" id="view_task">
<h1 class=" "> View Task <hr></h1>
<?php 
if(isset($_GET['suc']))
{
    echo "<div class='  p-2  bg-success  text-white '> TASK ID -> ".$_GET['suc']." has been deleted</div>"; 

}

?> 



<thead class="table-dark ">
        <tr>
            <th > TASK ID</th>
            <th > TASK NAME</th>
            <th > TASK Description</th>
            <th > Task Date</th>

            <th > Task Completed </th>

            <th > Action</th>
        </tr>
    </thead>
    <tbody>

        <?php
while($row=$qry_exe->fetch_assoc())
{
    ?>


<?php if($row['done']==1) 
        { 
            echo "<tr class='bg-success text-white' id=".$row['id'].">";
        }

        else if($row['done']==0) 
        { 
            echo "<tr class='bg-danger text-white' id=".$row['id'].">";
        }

        ?>
       
           <td><?php echo $row['id'];?></td>
           <td><?php echo $row['name'];?></td>
           <td><?php echo $row['description'];?></td>
           <td><?php echo $row['date'];?></td>

           <td>

           <fieldset id="id_<?php echo $row['id'];?>">


      
           <input name="done_<?php echo $row['id'];?>" type="radio" id="done" onChange="changeValue(<?php echo $row['id'];?>)" value="1"  <?php echo ($row['done']== '1') ?  "checked" : "" ;  ?>/> YES
           <input name="done_<?php echo $row['id'];?>" type="radio" id="done" onChange="changeValue(<?php echo $row['id'];?>)" value="0" <?php echo ($row['done']== '0') ?  "checked" : "" ;  ?>/> No
</fieldset>


           </td>

           <td>  
               <center>
            <a class="ml-auto btn btn-primary border-white" href="view_task.php?id=<?php echo $row['id'];?>">View / Update</a>
            <a class="mr-auto btn btn-danger border-white" href="del_task.php?id=<?php echo $row['id'];?>">Delete</a>
</center>
       </td>


         

        </tr>
<?php } ?>

    </tbody>
    </table>
    </div>
    <script>
$(document).ready( function () {
    $('#view_task').DataTable();
} );

</script>
