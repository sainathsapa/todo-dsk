<?php

require('inc/nav.php');

$val = $_GET['id'];

$SQL_SELECT = "SELECT * FROM `todo` WHERE `id`='$val'";

$qry_select =$conn->query($SQL_SELECT);



$row=$qry_select->fetch_assoc();


if($row['done']==1)
{
    $new_val = 0;
}
else if($row['done']==0)
{
    $new_val =1;
}

    $SQL_insert = "UPDATE `todo` SET `done`='$new_val' WHERE id=$val";
    

    // Running Query


    if($conn->query($SQL_insert))
    {
       $msg="suc"; 
    }
    else
    {
        echo "error".mysqli_error($conn);
    }


