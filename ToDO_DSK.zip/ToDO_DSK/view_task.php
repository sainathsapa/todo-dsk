<?php

require('inc/nav.php');

$id=$_GET['id'];


//RUN CODE IF HIT SUBMIT
if(isset($_POST['submit']))
{
    
// Getting VALUES FROm FORM

    $task_name = $_POST['task_name'];
    $date = $_POST['date'];
    $description_task = $_POST['description'];

    // SQL Query

    $SQL_insert = "UPDATE `todo` SET `name`='$task_name', `date`='$date',  `description`='$description_task' WHERE id=$id";

    // Running Query


    if($conn->query($SQL_insert))
    {
       $msg="suc"; 
       
    }
    else
    {
        $msg="err_ins";
    }





}


$qry_select = "SELECT * FROM todo WHERE id='$id'";
$qry_exe = $conn->query($qry_select);

$row=$qry_exe->fetch_assoc();






?>



<br>
<form class="form container box-shadow_form card p-4 table-bordered" action="#" method="POST">
    <h1> <b></b>View TASK</h1> 

    <?php
     if(isset($_POST['submit']))
     {
         if($msg=='suc')
         {
            
             echo '   <div class="ml-auto"> <div class=" btn-success col-md btn-lg col-md-12"><a class="text-white" href="view.php"> <b> Update Succesfull  Go Back </a><div >
            
         </div></b> </div> </div>
             ';
         
         }
 
         if($msg=='err_ins')
         {
             echo '    <div class="ml-auto"> <div class=" btn-danger col-md btn-lg col-md-12"> <b> Something went Wrong.! </b> </div> </div>
             ';
 
         }
     }
     ?>
            

            
            
       </div></b> </div>            

        

    <br>

    <div class="row">

        <div class="col-md col-md-7">
            <label class="label form" for="task_name"><b>Task Name : </b></label> <br>
            <input class="form-control " type="text" name="task_name"  value="<?php echo $row['name'];?>" required>
        </div>
        <br>
        <div class="col-md-5 col-sm-12">
            


        <label class="label form" for="Date"><b>Date : </b></label> <br>
            <input class="form-control " type="date" name="date" value="<?php echo $row['date'];?>" required>



        </div>
    </div>

    <div class="row">

        <div class="col-md col-md-7">
            <label for="description"><b>Description: </b></label> <br>
            <textarea class="form-control " type="text" name="description" placeholder="Description" ><?php echo $row['description'];?> </textarea>
        </div>

        
    </div>
    <br>
    <br> <input class="btn btn-primary" type="submit" value="Update" name="submit">

</form>
