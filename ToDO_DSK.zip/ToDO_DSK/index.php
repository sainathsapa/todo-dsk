<?php

require('inc/nav.php');

?>

<br>
<br>

<div class="container card">
    <div class="row col-md-12">
        <div class=" col-md-4 m-1 bg-primary text-white text-center">
            <br>
            <br>
            <b> Total TASKS </b> <br>
            <strong>
                <?php
                $qry_ = "SELECT count(id) as count_row FROM todo";
                $qry_exe = $conn->query($qry_);
                $row_pt = $qry_exe->fetch_assoc();

                echo $row_pt['count_row'];




                ?>
            </strong>

        </div>

        <br> <br>
        <div class="col-md-4 text-center bg-danger text-white m-1 border-white">
            <br> <br>
            <b> Not Completed TASKS </b> <br> <strong>
                <?php
                $qry_ = "SELECT count(id) as count_row FROM todo WHERE done=0";
                $qry_exe = $conn->query($qry_);
                $row_pt = $qry_exe->fetch_assoc();

                echo $row_pt['count_row'];




                ?>
                <br>
            </strong>
        </div>



        <br> <br>
        <div class="col-md-3 text-center bg-success m-1 text-white">
            <br> <br>
            <b> Completed TASKS </b> <br> <strong>
                <?php
                $qry_ = "SELECT count(id) as count_row FROM todo WHERE done=1";
                $qry_exe = $conn->query($qry_);
                $row_pt = $qry_exe->fetch_assoc();

                echo $row_pt['count_row'];




                ?>
                <br>
            </strong>
        </div>


    </div>


    <br>

</div>